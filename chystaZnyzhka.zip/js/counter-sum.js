$(document).ready(function() {
    var total       = parseInt($('.counter__sum').html());
    var totalOne    = parseInt($('.group-one').html());
    var totalTwo    = parseInt($('.group-two').html());
    var totalThree  = parseInt($('.group-three').html());
    var totalFour   = parseInt($('.group-four').html());
    var totalFive   = parseInt($('.group-five').html());
    var totalSix    = parseInt($('.group-six').html());

    function counterSum(){
        if ($('.counter__sum').html() == 1800){
            $('#overlay-dark').fadeIn(400,
                function(){
                    $('#modal_promo')
                        .css('display', 'block')
                        .animate({opacity: 1, top: '50%'}, 200);
                    Promokode();
                });
        }
    }
    $( ".pic-one" ).click(function(){
        total = total + totalOne;
        $('.counter__sum').html(total);
        counterSum();

    });

    $( ".pic-two" ).click(function(){
        total = total + totalTwo;
        $('.counter__sum').html(total);
        counterSum();
    });

    $( ".pic-three" ).click(function(){
        total = total + totalThree;
        $('.counter__sum').html(total);
        counterSum();
    });

    $( ".pic-four" ).click(function(){
        total = total + totalFour;
        $('.counter__sum').html(total);
        counterSum();
    });

    $( ".pic-five" ).click(function(){
        total = total + totalFive;
        $('.counter__sum').html(total);
        counterSum();
    });

    $( ".pic-six" ).click(function(){
        total = total + totalSix;
        $('.counter__sum').html(total);
        counterSum();
    });
});