//модальное окно с правилами
$(document).ready(function() {
    setTimeout(function(){
        $('#modal_form')
            .css('display', 'block')
            .css("opacity", '1');
        $('#overlay-opacity').fadeIn(400);
    },500);

    $('.form__link').click( function(){
        $('#modal_form')
            .animate({opacity: 0, top: '45%'}, 200,
                function(){
                    $(this).css('display', 'none');
                    $('#overlay-opacity').fadeOut(400);
                }
            );
    });
});
function Promokode(){
    var total       = parseInt($('.counter__sum').html());
    var percent     = 0;

    var codesList = {
        "02": "AZf", //02AZf20
        "04": "BYz", //04BYz22
        "06": "CXk", //06CXk24
        "08": "DWq", //08DWq26
        "10": "EVv", //10EVv28
        "12": "FUk", //12FUk30
        "14": "GTq", //14GTq32
        "16": "HSz", //16HSz34
        "18": "GRg", //18GRg36
        "20": "KQt", //20KQt38
        "22": "LPp", //22LPp40
        "24": "MSa", //24MSa42
        "26": "NNm", //26NNm44
        "28": "KMf", //28KMf46
        "30": "PLj", //30PLj48
        "32": "QKk", //32QKk50
        "34": "RHr", //34RHr52
        "36": "SGg", //36SGg54
        "38": "TGx", //38TGx56
        "40": "UFm", //40UFm58
        "42": "VEn", //42VEn60
        "44": "WDf", //44WDf62
        "46": "XCs", //46XCs64
        "48": "YBk", //48YBk66
        "50": "ZAb",//50ZAb68
    };

    var result = Math.round(total/30)%2;

    if (result==0){
        var percent= Math.round(total/30);
    }
    else{
        var percent= Math.round(total/30)+1;
    }
    $('#promo-procent').html(percent);

    if      (percent ==  2) {setPromokode('02')}
    else if (percent ==  4) {setPromokode('04')}
    else if (percent ==  6) {setPromokode('06')}
    else if (percent ==  8) {setPromokode('08')}
    else if (percent == 10) {setPromokode('10')}
    else if (percent == 12) {setPromokode('12')}
    else if (percent == 14) {setPromokode('14')}
    else if (percent == 16) {setPromokode('16')}
    else if (percent == 18) {setPromokode('18')}
    else if (percent == 22) {setPromokode('22')}
    else if (percent == 24) {setPromokode('24')}
    else if (percent == 26) {setPromokode('26')}
    else if (percent == 28) {setPromokode('28')}
    else if (percent == 30) {setPromokode('30')}
    else if (percent == 32) {setPromokode('32')}
    else if (percent == 34) {setPromokode('34')}
    else if (percent == 36) {setPromokode('36')}
    else if (percent == 38) {setPromokode('38')}
    else if (percent == 40) {setPromokode('40')}
    else if (percent == 42) {setPromokode('42')}
    else if (percent == 44) {setPromokode('44')}
    else if (percent == 46) {setPromokode('46')}
    else if (percent == 48) {setPromokode('48')}
    else if (percent == 50) {setPromokode('50')}

    function setPromokode(percent) {
        var  promo = percent + codesList[percent] + (18 + +percent);
        $('#promo-code').html(promo);
    }
}
//модальное окно Промокода
$(document).ready(function() {
    $('.counter__link').click( function(event){
        event.preventDefault();

        $('#overlay-dark').fadeIn(400,
            function(){
                $('#modal_promo')
                    .css('display', 'block')
                    .animate({opacity: 1, top: '50%'}, 200);
                Promokode();
            });

    });

    $('#modal_close, #overlay-dark').click(function(){
        $('#modal_promo')
            .animate({opacity: 0, top: '45%'}, 200,
                function(){
                    location.reload();
                    $(this).css('display', 'none');
                    $('#overlay-dark').fadeOut(400);
                }
            );
    });
//движение картинок и появление балов
    $('#first').click( function(){
        $('.main__img1').addClass( 'animate-change' );
        $( ".one" ).css('display', 'block');
    });

    $('#second').click( function(){
        $('.main__img2').addClass( 'animate-change' );
        $( ".two" ).css('display', 'block');
    });

    $('#third').click( function(){
        $('.main__img3').addClass( "animate-change" );
        $( ".three" ).css('display', 'block');
    });

    $('#four').click( function(){
        $('.main__img4').addClass( "animate-change" );
        $( ".four" ).css('display', 'block');
    });

    $('#five').click( function(){
        $('.main__img5').addClass( "animate-change" );
        $( ".five" ).css('display', 'block');
    });

    $('#six').click( function(){
        $('.main__img6').addClass( "animate-change" );
        $( ".six" ).css('display', 'block');
    });

    $('#seven').click( function(){
        $('.main__img7').addClass( "animate-change" );
        $( ".seven" ).css('display', 'block');
    });

    $('#eight').click( function(){
        $('.main__img8').addClass( "animate-change" );
        $( ".eight" ).css('display', 'block');
    });

    $('#nine').click( function(){
        $('.main__img9').addClass( "animate-change" );
        $( ".nine" ).css('display', 'block');
    });

    $('#ten').click( function(){
        $('.main__img10').addClass( "animate-change" );
        $( ".ten" ).css('display', 'block');
    });

    $('#eleven').click( function(){
        $('.main__img11').addClass( "animate-change" );
        $( ".eleven" ).css('display', 'block');
    });

    $('#twelve').click( function(){
        $('.main__img12').addClass( "animate-change" );
        $( ".twelve" ).css('display', 'block');
    });
    $('#thirteen').click( function(){
        $('.main__img13').addClass( "animate-change" );
        $( ".thirteen" ).css('display', 'block');
    });

    $('#fourteen').click( function(){
        $('.main__img14').addClass( "animate-change" );
        $( ".fourteen" ).css('display', 'block');
    });

    $('#fifteen').click( function(){
        $('.main__img15').addClass( "animate-change" );
        $( ".fifteen" ).css('display', 'block');
    });

    $('#sixteen').click( function(){
        $('.main__img16').addClass( "animate-change" );
        $( ".sixteen" ).css('display', 'block');
    });

    $('#seventeen').click( function(){
        $('.main__img17').addClass( "animate-change" );
        $( ".seventeen" ).css('display', 'block');
    });
});