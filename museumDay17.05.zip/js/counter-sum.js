$(document).ready(function() {
    var total       = parseInt($('.counter__sum').html());
    var totalOne    = parseInt($('.group-one').html());
    var totalTwo    = parseInt($('.group-two').html());
    var totalThree  = parseInt($('.group-three').html());
    var totalFour   = parseInt($('.group-four').html());
    var totalFive   = parseInt($('.group-five').html());
    var totalSix    = parseInt($('.group-six').html());

    $( ".pic-one" ).click(function(){
        total = total + totalOne;
        $('.counter__sum').html(total);

        if ($('.counter__sum').html() == 1500){
            $('#overlay-dark').fadeIn(400,
                function(){
                    $('#modal_promo')
                        .css('display', 'block')
                        .animate({opacity: 1, top: '50%'}, 200);
                    Promokode();
                });
        }
    });

    $( ".pic-two" ).click(function(){
        total = total + totalTwo;
        $('.counter__sum').html(total);

        if ($('.counter__sum').html() == 1500){
            $('#overlay-dark').fadeIn(400,
                function(){
                    $('#modal_promo')
                        .css('display', 'block')
                        .animate({opacity: 1, top: '50%'}, 200);
                    Promokode();
                });
        }
    });
    $( ".pic-three" ).click(function(){
        total = total + totalThree;
        $('.counter__sum').html(total);

        if ($('.counter__sum').html() == 1500){
            $('#overlay-dark').fadeIn(400,
                function(){
                    $('#modal_promo')
                        .css('display', 'block')
                        .animate({opacity: 1, top: '50%'}, 200);
                    Promokode();
                });
        }
    });
    $( ".pic-four" ).click(function(){
        total = total + totalFour;
        $('.counter__sum').html(total);

        if ($('.counter__sum').html() == 1500){
            $('#overlay-dark').fadeIn(400,
                function(){
                    $('#modal_promo')
                        .css('display', 'block')
                        .animate({opacity: 1, top: '50%'}, 200);
                    Promokode();
                });
        }
    });
    $( ".pic-five" ).click(function(){
        total = total + totalFive;
        $('.counter__sum').html(total);

        if ($('.counter__sum').html() == 1500){
            $('#overlay-dark').fadeIn(400,
                function(){
                    $('#modal_promo')
                        .css('display', 'block')
                        .animate({opacity: 1, top: '50%'}, 200);
                    Promokode();
                });
        }
    });
    $( ".pic-six" ).click(function(){
        total = total + totalSix;
        $('.counter__sum').html(total);

        if ($('.counter__sum').html() == 1500){
            $('#overlay-dark').fadeIn(400,
                function(){
                    $('#modal_promo')
                        .css('display', 'block')
                        .animate({opacity: 1, top: '50%'}, 200);
                    Promokode();
                });
        }
    });
});