(function () {
    range = $('.range-slider.uah > .input-range');
    value = $('.range-slider.uah > .range-value');

    value.val(range.attr('value'));

    range.on('input', function(){
        monparent=this.parentNode;

        value=$(monparent).find('.range-value');
        $(value).val(this.value);

        calcResult(this.value, document.getElementById('valueDays').value);

    });

    value.on('input', function(){
        monparent=this.parentNode;
        range=$(monparent).find('.input-range');
        $(range).val(this.value);

        calcResult(this.value, document.getElementById('valueDays').value);
    });
}());

(function () {
    range = $('.range-slider.day > .input-range');
    value = $('.range-slider.day > .range-value');
    calendar = $('#calendar');

    value.val(range.attr('value'));

    range.on('input', function(){
        monparent=this.parentNode;

        value=$(monparent).find('.range-value');
        $(value).val(this.value);

        calcResult(document.getElementById('valueSum').value, this.value);
    });

    value.on('input', function(){
        monparent=this.parentNode;
        range=$(monparent).find('.input-range');
        $(range).val(this.value);

        calcResult(document.getElementById('valueSum').value, this.value);
    });

    calendar.on('input', function(){
        monparent=this.parentNode.parentNode;
        value=$(monparent).find('.range-value');

        var datetime = new Date();
        datetime.getTime();

        countResult = Math.ceil(((new Date(this.value).getTime()) - datetime.getTime())/86400000);

        if (countResult <= 0) {
            $(value).val('1');
            $(range).val('1');
        } else if (countResult > 30) {
            $(value).val('30');
            $(range).val('30');
        } else {
            $(value).val(countResult);
            $(range).val(countResult);
        }

        calcResult(document.getElementById('valueSum').value, document.getElementById('valueDays').value)
    });
}());

setDate();
function setDate() {
    var daysDate = document.getElementById('valueRangeDays').value,
        returnDateTag = document.getElementById('returnDate');
    var d = new Date();
    d.setDate(d.getDate() +  +daysDate);
    var endDate = new Date(d).toLocaleString('ru', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        weekday: 'short'
    });
    returnDateTag.innerHTML = endDate;
}

function calcResult(sum, days, date) {
    var uahTag = document.getElementById('uah'),
        percentTag = document.getElementById('percent'),
        amountTag = document.getElementById('amount');

    uahTag.innerHTML = sum;
    var percentCount = (1/10000 * sum * days).toFixed(2);
    percentTag.innerHTML = percentCount;
    var amountCount = +percentCount + +sum;
    amountTag.innerHTML = amountCount.toFixed(2);

    setDate();
}
(function (){
    var timer = document.getElementById('time'),
        date = new Date(),
        nowHour = date.getHours(),
        nowMinutes = date.getMinutes();
    if (nowHour < 10) {
        nowHour = '0'+nowHour;
    }
    if (nowMinutes < 10 ) {
        timer.innerHTML = nowHour + ':' + (nowMinutes + 8);
    } else if (nowMinutes > 51) {
        timer.innerHTML = (nowHour + 1) + ':0' + (8 - (60 - nowMinutes));
    } else {
        timer.innerHTML = nowHour + ':' + (nowMinutes + 8);
    }
    if (nowMinutes < 10) {
        nowMinutes = '0'+nowMinutes;
    }
}());
$('#myCarousel').carousel({
    interval: 10000
})
var windowWidth = $(window).width();
if(windowWidth > 770){
    $('.carousel .item').each(function(){
        var next = $(this).next();
        if (!next.length) {
            next = $(this).siblings(':first');
        }
        next.children(':first-child').clone().appendTo($(this));
    });
}
$(document).ready(function () {
    $(".navbar-toggle").on("click", function () {
        $(this).toggleClass("active");
        $(this).toggleClass('b-sandwich_close');
    });
    $(".b-menu__link").on("click", function () {
        $(".b-header__menu ").collapse('hide');
        $(".navbar-toggle").toggleClass("active");
        $(".navbar-toggle").toggleClass('b-sandwich_close');
    });
});
